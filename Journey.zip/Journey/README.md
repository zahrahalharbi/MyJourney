# My Journal

# Challenge 3 - Make Someone’s Life Easier

##Topics Included in this Readme File:
Big Idea
Challenge Statement
Solution Concept
List of technologies I used to develop this app
Upcoming Features
a brief demo of the app
Challenge Summary

## Our Big Idea:

Make a Free space for a Diary

## Challeng Statement:

Make an inclusive a Free space for people to write and add images about their journey

## Solution Concept:

A diary for those who want to express their feelings to keep great memories so that they can remember it

## Technologies & Tools: 

1. Xcode (SwiftUI, UIKit)
2. Image picker
3. Sketch
4. Accessibility (Voice Over)
5. Localization

##Upcoming Features:

1. Add your expression to the diary
2. Add voice recording

## Demo of Our App



## Challenge Summary

<img src= "https://user-images.githubusercontent.com/111164258/212462673-d79c94ac-7e73-4bc9-91a7-e710d051fe70.png">

