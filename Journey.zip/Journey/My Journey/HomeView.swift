//
//  HomeView.swift
//  My Journey
//
//  Created by Zahrah. on 11/01/2023.
//

import Foundation

import SwiftUI

struct HomeView: View {
    @EnvironmentObject var imageData : ImageData
    var body: some View {
        
        List {
            ForEach(imageData.imageNote) { note in
                NavigationLink(destination: NoteDetailView(note: note)) {
                    
                    HStack {
                        Image(uiImage: UIImage(data: note.image)!)
                            .resizable()
                            .frame(width: 50, height: 50, alignment: .center)
                        
                        VStack(alignment: .leading) {
                            Text(note.title)
                                .lineLimit(2)
                        }
                    }
                    //.onDelete(perform: ImageNote.reset)
                    
                    //                }                  } .onDelete(perform:resetUserData)
                }.scrollContentBackground(.hidden)
                //                .onDelete(perform:resetUserData)
                
                
            }.scrollContentBackground(.hidden)
//            .onDelete(perform: reset)
        }
    }

//    func reset(at offsets: IndexSet){
//        imageNote.remove(atOffsets: offsets)
//
//        //imageNote = []
//    }
}
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .environmentObject(ImageData())
    }
}


