//
//  NoteDetailView.swift
//  My Journey
//
//  Created by Zahrah. on 11/01/2023.
//

import Foundation

import SwiftUI

struct NoteDetailView: View {
    
    @EnvironmentObject var imageData : ImageData
    @State var note: ImageNote
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        Form {
            Section {
                HStack {
                    Spacer()
                    Image(uiImage: UIImage(data: note.image)!)
                        .resizable()
                        .frame(width: 342, height: 236, alignment: .center)
                        .cornerRadius(10)
                    Spacer()
                }
                TextField("Title", text: $note.title)
                    .textSelection(.enabled)
                    .font(.largeTitle)
                    .onTapGesture {
                        note.title = ""
                    }
                    .accessibilityHint(Text("Add title"))
                
            
                ZStack {
                    TextEditor(text: $note.description)
                        .textSelection(.enabled)
                        .frame(height:280)
                        
                   
                    
                    VStack {
                        Spacer()
                        HStack {
                            Spacer()
                            Text("\(note.description.count)/300")
                                .foregroundColor(.gray)
                                .padding()
                                
                        }
                    }
                }
               
                HStack {
                    Spacer()
                    Button("Confirm changes") {
                        imageData.editNote(id: note.id, title: note.title, description: note.description)
                        presentationMode.wrappedValue.dismiss()
                    }
                    
                    Spacer()
                }
                .accessibilityHint(Text("Confirm Changes"))
            } .listRowSeparator(.hidden)
        }
        .scrollContentBackground(.hidden)
        
    }
}

struct NoteDetailView_Previews: PreviewProvider {
    static var previews: some View {
    let tempImage = UIImage(systemName: "map")?.pngData()
        
        NoteDetailView(note: ImageNote(id: UUID(), image: tempImage!, title: "", description: ""))
            .environmentObject(ImageData())
    }
}
