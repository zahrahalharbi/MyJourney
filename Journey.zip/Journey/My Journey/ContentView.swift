//
//  ContentView.swift
//  My Journey
//
//  Created by Zahrah. on 11/01/2023.
//

import SwiftUI

struct ContentView: View {
    @StateObject var imageData = ImageData()
    @State var showImagePicker: Bool = false
    
    var body: some View {
        NavigationView {
            VStack {
                if imageData.imageNote.isEmpty {
                    Text(" Add memory! ")
                        .italic()
                        .foregroundColor(.gray)
                } else {
                    HomeView()
                }
            }
            .navigationTitle("My Journey ")
            

            .sheet(isPresented: $showImagePicker) {
                ImagePicker(sourceType: .photoLibrary) { image in
                    imageData.addNote(image: image,
                                      title:"",
                                      desc:"")
                    
                    
                   
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showImagePicker.toggle()
                    } label: {
                        Label("Image", systemImage: "plus")
                    }.accessibilityHint(Text("Add new journey"))
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        withAnimation {
                            imageData.resetUserData()
                        }
                    } label: {
                        Label("Image", systemImage: "trash")
                    } .accessibilityHint(Text("Delete"))
                    .tint(.red)
                    //EditButton()
                }
             
            }.tint(Color("LightBlue"))
        }
        .environmentObject(imageData)
    }
    //func reset(at offsets: IndexSet){
   //        imageNote.remove(atOffsets: offsets)
   //
   //        //imageNote = []
   //    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
