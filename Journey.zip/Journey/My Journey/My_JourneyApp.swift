//
//  My_JourneyApp.swift
//  My Journey
//
//  Created by Zahrah. on 11/01/2023.
//

import SwiftUI

@main
struct My_JourneyApp: App {
    init() {
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor : UIColor(Color("LightBlue"))]
    }
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}


